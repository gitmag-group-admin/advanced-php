<?php
session_start();

const BASE_URL = 'http://localhost:8000/';

function asset($file) {
    return BASE_URL . 'assets/' . $file;
}

function dd($data) {
    die('<pre>' . var_export($data, true) . '</pre>');
}

function redirect($path) {
    header("location: $path");
    exit();
}

function get_excerpt($content, $count = 150) {
    return substr($content, 0, $count) . '...';
}

function get_data($data_file) {
    $file_address = './database/' . $data_file . '.json';
    $file = fopen($file_address, "r+");
    $database = fread($file, filesize($file_address));
    fclose($file);

    return json_decode($database, true);
}

function set_data($data_file, $new_data) {
    $new_data = json_encode($new_data);

    $file_address = './database/' . $data_file . '.json';
    $file = fopen($file_address, "w+");
    $database = fwrite($file, $new_data);
    fclose($file);

    return true;
}
 
function get_posts_order_by_views($posts) {
    uasort($posts, function($first, $second) {
        if ($first['view'] > $second['view']) {
            return -1;
        } else {
            return 1;
        }
    });

    $posts = array_values($posts);
    return count($posts)? $posts : null;
}

function get_posts_order_by_date($posts) {
    uasort($posts, function($first, $second) {
        if(strtotime($first['date']) > strtotime($second['date'])) {
            return -1;
        } else {
            return 1;
        }
    });

    $posts = array_values($posts);
    return count($posts)? $posts : null;
}

function get_last_post($posts) {
    uasort($posts, function($first, $second) {
        if ($first['id'] > $second['id']) {
            return -1;
        } else {
            return 1;
        }
    });

    $posts = array_values($posts);
    return $posts[0];
}

function get_post_by_id($posts, $id) {
    $post = array_filter($posts, function($post) use($id){
        if($post['id'] == $id) {
            return true;
        } else {
            return false;
        }
    });

    $post = array_values($post);
    return (count($post))? $post[0] : null;
}

function get_posts_by_word($posts, $search) {
    $search = trim($search);
    $posts = array_filter($posts, function($post) use($search){
        if(strpos($post['title'], $search) !== false or strpos($post['content'], $search) !== false) {
            return true;
        } else {
            return false;
        }
    });

    $posts = array_values($posts);
    return count($posts)? $posts : null;
}

function get_posts_by_category($posts, $category) {
    $posts = array_filter($posts, function($post) use($category) {
        if($post['category'] == $category) {
            return true;
        } else {
            return false;
        }
    });

    $posts = array_values($posts);

    return count($posts)? $posts : null;
}

function delete_post($posts, $id) {
    $posts = array_filter($posts, function($post) use($id){
        if($post['id'] != $id) {
            return true;
        } else {
            delete_image($post['image']);
            return false;
        }
    });

    $posts = array_values($posts);
    set_data('posts', $posts);
    return true;
}

function create_post($posts, $title, $category, $content, $image) {
    $last_post = get_last_post($posts);
    $id = $last_post['id'] + 1;
    $image_name = upload_image($image);
    $new_post = [
        'id' => $id,
        'title' => $title,
        'content' => $content,
        'category' => $category,
        'view' => 0,
        'image' => $image_name,
        'date' => date('Y-m-d H:i:s')
    ];

    $posts[] = $new_post;
    set_data('posts', $posts);

    return true;
}

function validate_post($title, $category, $content, $image) {
    $errors = [];

    if(empty($title)) {
        $errors[] = 'Please fill title field.';
    } else if(strlen($title) < 3) {
        $errors[] = 'Please enter title bigger than 3 chars.';
    }

    if(empty($category)) {
        $errors[] = 'Please select one category.';
    } else if(! in_array($category, ['political', 'sport', 'social'])) {
        $errors[] = 'Selected category is invalid.';
    }

    if(empty($content)) {
        $errors[] = 'Please fill content field.';
    } else if(strlen($content) < 5) {
        $errors[] = 'Please enter content bigger than 5 chars.';
    }

    if(! is_array($image)) {
        $errors[] = 'Selected image is invalid.';
    } else if (empty($image['name'])) {
        $errors[] = 'Please fill image field.';
    } else if ($image['size'] > 500000) {
        $errors[] = 'Image size should be smaller than 5MB.';
    } else if (! in_array($image['type'], ['image/jpeg', 'image/png', 'image/gif'])) {
        $errors[] = 'Selected image is invalid.';
    }

    return $errors;
}

function edit_post($posts, $id, $title, $category, $content, $image) {
    $posts = array_map(function($post) use($id, $title, $content, $category, $image) {
        if($post['id'] == $id) {
            $post['title'] = $title;
            $post['content'] = $content;
            $post['category'] = $category;

            if(! empty($image['name'])) {
                delete_image($post['image']);
                $post['image'] = upload_image($image);
            }
        }

        return $post;
    }, $posts);

    set_data('posts', $posts);
    return true;
}

function validate_edit_post($title, $category, $content, $image) {
    $errors = [];

    if(empty($title)) {
        $errors[] = 'Please fill title field.';
    } else if(strlen($title) < 3) {
        $errors[] = 'Please enter title bigger than 3 chars.';
    }

    if(empty($category)) {
        $errors[] = 'Please select one category.';
    } else if(! in_array($category, ['political', 'sport', 'social'])) {
        $errors[] = 'Selected category is invalid.';
    }

    if(empty($content)) {
        $errors[] = 'Please fill content field.';
    } else if(strlen($content) < 5) {
        $errors[] = 'Please enter content bigger than 5 chars.';
    }

    if(!empty($image['name'])) {
        if(! is_array($image)) {
            $errors[] = 'Selected image is invalid.';
        } else if ($image['size'] > 500000) {
            $errors[] = 'Image size should be smaller than 5MB.';
        } else if (! in_array($image['type'], ['image/jpeg', 'image/png', 'image/gif'])) {
            $errors[] = 'Selected image is invalid.';
        }
    }


    return $errors;
}

function login($users, $email, $password) {
    $user = array_filter($users, function($user) use($email, $password) {
        if($user['email'] == $email and $user['password'] == $password) {
            return true;
        } else {
            return false;
        }
    });

    $user = array_values($user);

    return count($user)? $user[0] : null;
}

function validate_login($email, $password) {
    $errors = [];

    if(empty($email)) {
        $errors[] = 'Plaese fill email field.';
    } else if(! filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Plase enter a valid email.';
    }

    if(empty($password)) {
        $errors[] = 'Please fill password field.';
    }

    return $errors;
}

function authenticated() {
    if(isset($_SESSION['user'])) {
        return true;
    } else {
        return false;
    }
}

function logout() {
    unset($_SESSION['user']);
    redirect('login.php');
}

function get_user_data() {
    if(authenticated()) {
        return $_SESSION['user'];
    } else {
        return null;
    }
}

function upload_image($file) {
    $dir = 'assets/images/';
    $name = $file['name'];
    $extension = pathinfo($name, PATHINFO_EXTENSION);
    $new_name = time() . '.' . $extension;
    $tmp = $file['tmp_name'];

    if(move_uploaded_file($tmp, $dir . $new_name)) {
        return "images/$new_name";
    } else {
        return '';
    }
}

function delete_image($image) {
    if (file_exists('assets/' . $image)) {
        unlink('assets/' . $image);
        return true;
    } else {
        return false;
    }
}