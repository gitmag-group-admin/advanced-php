<footer>
    <p><?= $setting['footer'] ?></p>
</footer>