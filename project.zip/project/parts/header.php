<header>
    <h1><?= $setting['title'] ?></h1>
    <div id="logo">
        <img src="<?= asset($setting['logo']) ?>" alt="Gitmag">
    </div>
</header>