<?php

require('./functions.php');

if(! authenticated()) {
    redirect('index.php');
}

logout();

?>