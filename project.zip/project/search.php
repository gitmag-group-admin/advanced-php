<?php

require('./functions.php');

if(!isset($_GET['search'])) {
    redirect('index.php');
}

$search = $_GET['search'];
$setting = get_data('setting');
$posts = get_data('posts');
$top_posts = get_posts_order_by_views($posts);
$last_posts = get_posts_order_by_date($posts);
$search_posts = get_posts_by_word($posts, $search);
?>

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="<?= $setting['description'] ?>">
        <meta name="keyword" content="<?= $setting['keywords'] ?>">
        <meta name="author" content="<?= $setting['author'] ?>">

        <title><?= $setting['title'] ?></title>
        <link rel="stylesheet" href="<?= asset('css/style.css') ?>">
    </head>

    <body>
        <main>
            <?php require('./parts/header.php') ?>
            <?php require('./parts/navbar.php') ?>
            <section id="content">
                <?php require('./parts/sidebar.php') ?>
                <?php if($search_posts): ?>
                    <div id="articles">
                        <?php foreach($search_posts as $post): ?>
                            <article>
                                <div class="caption">
                                    <h3><?= $post['title'] ?></h3>
                                    <ul>
                                        <li>Date: <span><?= date('Y M d', strtotime($post['date'])) ?></span></li>
                                        <li>Views: <span><?= $post['view'] ?> view</span></li>
                                    </ul>
                                    <p><?= get_excerpt($post['content']) ?></p>
                                    <a href="single.php?post=<?= $post['id'] ?>">More...</a>
                                </div>
                                <div class="image">
                                    <img src="<?= asset($post['image']) ?>" alt="<?= $post['title'] ?>">
                                </div>
                                <div class="clearfix"></div>
                            </article>
                        <?php endforeach ?>
                    </div>
                <?php else: ?>
                    <div id="articles">
                        Does not exists any data.
                    </div>
                <?php endif ?>
                <div class="clearfix"></div>
            </section>
            <?php require('./parts/footer.php') ?>
        </main>
    </body>
</html>